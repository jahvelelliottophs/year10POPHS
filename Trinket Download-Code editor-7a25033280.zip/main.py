print ("league registration")
name =input("Enter First Name: >>>")
nickname =input("Enter your nickname: >>>")
email =input ("enter your email address")
skill =input ("Enter skill level - E for expert or C for casual : >>> ")
print ("please review your details")
print("")
print("")
print("")
print("your name is",name,)
print("your nickname is",nickname,)
print("your email is",email,)


if skill== ("c")or("C") :
  print ("skill level is casual")
elif skill ==("e")or("E"):
  print ("skill level is expert")






































